# 💰 KWQ8 PAYWALL & CONVERSION SYSTEM
## Multi-Step Paywall Strategy Based on Vah's Methodology | December 2025

---

# EXECUTIVE SUMMARY

This specification implements a scientifically-designed paywall system based on proven conversion optimization principles. The core philosophy: **Growth ≠ More Users. Growth = Stopping Revenue Leaks.**

KWQ8's paywall system uses multi-step flows, psychological pricing, strategic placement, and behavioral triggers to maximize trial-to-paid conversion (target: 30%+).

---

# PART 1: PAYWALL PHILOSOPHY

## 1.1 Core Principles

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         PAYWALL PHILOSOPHY                                  │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ❌ WRONG APPROACH:                                                         │
│  "We need more users" → Spend on ads → Low conversion → Leaky bucket       │
│                                                                             │
│  ✅ RIGHT APPROACH:                                                         │
│  "Fix the paywall" → Higher conversion → Same users → More revenue         │
│                                                                             │
│  ─────────────────────────────────────────────────────────────────────────  │
│                                                                             │
│  KEY INSIGHT:                                                               │
│  Every user at the paywall is a potential customer.                        │
│  A 5% improvement in paywall conversion = 5% revenue increase              │
│  with ZERO additional marketing spend.                                     │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

## 1.2 The 22 Rules (Adapted for KWQ8)

### FREE TRIAL RULES
1. Mention "تجربة مجانية" (free trial) **5+ times** across the flow
2. Remove trial length from the main price card (show it separately)
3. Add a screen showing the trial reminder timeline
4. Make the free trial card only say "مجاناً" (Free), not "الباقة الأساسية"
5. Frame everything around "ليس لديك ما تخسره" (You have nothing to lose)

### PRICING RULES
6. Use psychological prices (22.99, 37.5, not 23, 38)
7. Let users pick: trial vs. no trial
8. Make "no trial" slightly cheaper (incentive for immediate commitment)
9. Only discount annual plans - never weekly or monthly
10. Anchor annual as "فقط X دينار أسبوعياً" (only X KWD/week)

### CONVERSION PSYCHOLOGY RULES
11. Use multi-step paywalls (3 screens minimum)
12. Use visuals, timelines, reminders to reduce anxiety
13. Insert social proof (reviews, logos) on step 2 or 3
14. Hide detailed prices on main screen - reveal after clicking CTA
15. Use urgency tactics: "عرض محدود", "ينتهي قريباً"

### BEHAVIORAL OFFER RULES
16. Add a spin-wheel discount popup as excitement trigger
17. Trigger paywalls after high-intent actions (project created, AI used)
18. Add paywall after user cancels purchase popup (transaction abandonment)
19. Add paywall on every session start (1x/day, subtle)
20. Show "رصيدك على وشك النفاد" (credits running low) reminders

### BUSINESS RULES
21. If trial-to-paid ≥ 30%, consider removing the trial completely
22. Price test by comparing competitors, cost, and user intent

---

# PART 2: MULTI-STEP PAYWALL DESIGN

## 2.1 The 3-Step Paywall Flow

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                       3-STEP PAYWALL FLOW                                   │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  STEP 1: BENEFITS                    STEP 2: TRUST                          │
│  ┌─────────────────────────┐        ┌─────────────────────────┐            │
│  │                         │        │                         │            │
│  │  🚀 ابنِ موقعك بالذكاء   │        │  ⏰ تذكير الإلغاء        │            │
│  │     الاصطناعي           │  ──▶   │                         │            │
│  │                         │        │  📅 اليوم: تبدأ التجربة  │            │
│  │  ✓ مواقع غير محدودة     │        │  📅 اليوم 5: تذكير      │            │
│  │  ✓ قوالب عربية جاهزة   │        │  📅 اليوم 7: الدفع      │            │
│  │  ✓ دعم فني 24/7         │        │                         │            │
│  │  ✓ نشر مجاني            │        │  💡 يمكنك الإلغاء في     │            │
│  │                         │        │     أي وقت بضغطة واحدة   │            │
│  │  [ابدأ مجاناً ←]       │        │                         │            │
│  │                         │        │  [متابعة ←]              │            │
│  └─────────────────────────┘        └─────────────────────────┘            │
│                                                                             │
│                              STEP 3: OFFERS + SOCIAL PROOF                  │
│                              ┌─────────────────────────────┐               │
│                              │                             │               │
│                              │  اختر خطتك                  │               │
│                              │                             │               │
│                              │  ┌─────────┐  ┌─────────┐  │               │
│                              │  │ أسبوعية │  │ سنوية   │  │               │
│                              │  │         │  │ وفر 40% │  │               │
│                              │  │ 1 د.ك   │  │ 23 د.ك  │  │               │
│                              │  │ /أسبوع  │  │ /سنة    │  │               │
│                              │  └─────────┘  └─────────┘  │               │
│                              │                             │               │
│                              │  ⭐⭐⭐⭐⭐ "أفضل أداة..."     │               │
│                              │  - أحمد، الكويت             │               │
│                              │                             │               │
│                              │  [ابدأ التجربة المجانية ←]  │               │
│                              │                             │               │
│                              └─────────────────────────────┘               │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

## 2.2 Step-by-Step Screens (Arabic)

### Step 1: Benefits Screen

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                    [✕ تخطي]                 │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│                           🚀                                                │
│                                                                             │
│                   ابنِ موقعك الاحترافي                                      │
│                   بالذكاء الاصطناعي                                         │
│                                                                             │
│  ─────────────────────────────────────────────────────────────────────────  │
│                                                                             │
│           ✓ صمم موقعك بالعربية في دقائق                                    │
│           ✓ قوالب احترافية جاهزة للخليج                                    │
│           ✓ نظام دفع متكامل (UPayments)                                    │
│           ✓ دعم فني على واتساب 24/7                                        │
│           ✓ نطاق مجاني للسنة الأولى                                        │
│                                                                             │
│  ─────────────────────────────────────────────────────────────────────────  │
│                                                                             │
│                      💎 جرّب مجاناً لمدة أسبوع                              │
│                         بدون أي التزام                                     │
│                                                                             │
│              ┌─────────────────────────────────────┐                        │
│              │      ابدأ تجربتك المجانية ←        │                        │
│              └─────────────────────────────────────┘                        │
│                                                                             │
│                  لن يتم خصم أي مبلغ اليوم                                   │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Step 2: Trust & Reminder Screen

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  [← رجوع]                                                                   │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│                           ⏰                                                │
│                                                                             │
│                   سنذكرك قبل انتهاء التجربة                                 │
│                                                                             │
│  ─────────────────────────────────────────────────────────────────────────  │
│                                                                             │
│    ┌─────────────────────────────────────────────────────────────────┐     │
│    │                                                                 │     │
│    │    📅 اليوم                                                    │     │
│    │    ───●────────────────────────────────────────────            │     │
│    │       ↓                                                         │     │
│    │    ✓ تبدأ تجربتك المجانية                                      │     │
│    │                                                                 │     │
│    │    📅 اليوم 5                                                  │     │
│    │    ──────────●─────────────────────────────────                │     │
│    │              ↓                                                  │     │
│    │    📧 سنرسل لك تذكيراً بالبريد والواتساب                        │     │
│    │                                                                 │     │
│    │    📅 اليوم 7                                                  │     │
│    │    ────────────────────────────────────────●                   │     │
│    │                                            ↓                    │     │
│    │    💳 يبدأ الاشتراك (يمكنك الإلغاء قبلها)                       │     │
│    │                                                                 │     │
│    └─────────────────────────────────────────────────────────────────┘     │
│                                                                             │
│    💡 يمكنك إلغاء اشتراكك في أي وقت من الإعدادات                          │
│       بضغطة واحدة فقط - بدون اتصال أو استفسارات                            │
│                                                                             │
│              ┌─────────────────────────────────────┐                        │
│              │           متابعة ←                 │                        │
│              └─────────────────────────────────────┘                        │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Step 3: Offers + Social Proof

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  [← رجوع]                                                                   │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│                         اختر خطتك المناسبة                                  │
│                                                                             │
│  ─────────────────────────────────────────────────────────────────────────  │
│                                                                             │
│    ┌─────────────────────────┐    ┌─────────────────────────┐              │
│    │                         │    │  ⭐ الأكثر توفيراً      │              │
│    │      أسبوعية            │    │                         │              │
│    │                         │    │      سنوية              │              │
│    │    ╭──────────────╮     │    │                         │              │
│    │    │              │     │    │    ╭──────────────╮     │              │
│    │    │  1 د.ك       │     │    │    │              │     │              │
│    │    │  /أسبوع      │     │    │    │  23 د.ك      │     │              │
│    │    │              │     │    │    │  /سنة        │     │              │
│    │    ╰──────────────╯     │    │    │              │     │              │
│    │                         │    │    │  وفّر 40%    │     │              │
│    │    52 د.ك/سنة          │    │    ╰──────────────╯     │              │
│    │                         │    │                         │              │
│    │    [○ اختيار]          │    │    فقط 0.44 د.ك/أسبوع   │              │
│    │                         │    │                         │              │
│    └─────────────────────────┘    │    [● محدد ✓]           │              │
│                                   │                         │              │
│                                   └─────────────────────────┘              │
│                                                                             │
│  ─────────────────────────────────────────────────────────────────────────  │
│                                                                             │
│    ⭐⭐⭐⭐⭐                                                                  │
│    "أفضل قرار اتخذته لمشروعي. بنيت موقعي في يوم واحد!"                      │
│    — فاطمة العنزي، صاحبة متجر إلكتروني                                      │
│                                                                             │
│  ─────────────────────────────────────────────────────────────────────────  │
│                                                                             │
│    💎 تجربة مجانية 7 أيام • إلغاء سهل • ضمان استرداد المال                  │
│                                                                             │
│              ┌─────────────────────────────────────┐                        │
│              │   ابدأ تجربتك المجانية الآن ←      │                        │
│              └─────────────────────────────────────┘                        │
│                                                                             │
│                   🔒 دفع آمن عبر UPayments                                 │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

# PART 3: TRIAL TOGGLE SYSTEM

## 3.1 Trial vs. No Trial Option

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                          TRIAL TOGGLE DESIGN                                │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│                         كيف تريد أن تبدأ؟                                   │
│                                                                             │
│    ┌───────────────────────────────────────────────────────────────────┐   │
│    │                                                                   │   │
│    │  ┌─────────────────────────┐  ┌─────────────────────────────┐    │   │
│    │  │                         │  │                             │    │   │
│    │  │  🎁 مع تجربة مجانية     │  │  💨 بدون تجربة              │    │   │
│    │  │                         │  │     (خصم 15%)               │    │   │
│    │  │  جرّب 7 أيام مجاناً     │  │                             │    │   │
│    │  │  ثم 23 د.ك/سنة         │  │  ابدأ الآن بـ 19.55 د.ك     │    │   │
│    │  │                         │  │                             │    │   │
│    │  │  ✓ إلغاء في أي وقت     │  │  ✓ توفير فوري               │    │   │
│    │  │  ✓ تذكير قبل الدفع     │  │  ✓ وصول كامل فوري           │    │   │
│    │  │                         │  │                             │    │   │
│    │  │  [● محدد]              │  │  [○ اختيار]                 │    │   │
│    │  │                         │  │                             │    │   │
│    │  └─────────────────────────┘  └─────────────────────────────┘    │   │
│    │                                                                   │   │
│    └───────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  WHY THIS WORKS:                                                            │
│  • Captures high-intent users who want immediate access (no trial)         │
│  • Captures cautious users who need the safety of a trial                  │
│  • Creates a "deal" perception for no-trial option                         │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

## 3.2 Toggle Implementation

```typescript
interface TrialToggleState {
  selectedOption: 'with_trial' | 'without_trial';
  pricing: {
    withTrial: {
      trialDays: 7;
      afterTrialPrice: number;  // 23 KWD
      displayPrice: 'مجاناً ثم 23 د.ك/سنة';
    };
    withoutTrial: {
      discountPercent: 15;
      finalPrice: number;       // 19.55 KWD
      displayPrice: '19.55 د.ك/سنة';
      savings: '3.45 د.ك';
    };
  };
}

// Conversion tracking
interface ToggleMetrics {
  impressions: number;
  withTrialClicks: number;
  withoutTrialClicks: number;
  conversionRate: {
    withTrial: number;
    withoutTrial: number;
  };
}
```

---

# PART 4: PAYWALL PLACEMENT STRATEGY

## 4.1 Placement Map

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         PAYWALL PLACEMENT MAP                               │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  PLACEMENT 1: POST-ONBOARDING ✓                                             │
│  ────────────────────────────────                                           │
│  When: User completes onboarding flow                                       │
│  Type: Full multi-step paywall                                              │
│  Why: High intent - they've invested time to set up                         │
│                                                                             │
│  PLACEMENT 2: FIRST AI GENERATION ✓                                         │
│  ────────────────────────────────                                           │
│  When: User tries to generate their first website                           │
│  Type: Soft paywall - "Subscribe to build unlimited sites"                  │
│  Why: Peak excitement moment - they want to see the magic                   │
│                                                                             │
│  PLACEMENT 3: CREDIT EXHAUSTION ✓                                           │
│  ────────────────────────────────                                           │
│  When: Free credits run out                                                 │
│  Type: Upgrade prompt with credit comparison                                │
│  Why: User has experienced value, now needs more                            │
│                                                                             │
│  PLACEMENT 4: SESSION START (1x/day) ✓                                      │
│  ────────────────────────────────                                           │
│  When: User returns to app (max once per 24 hours)                          │
│  Type: Subtle modal - "Continue where you left off with Pro"                │
│  Why: Regular reminder without being annoying                               │
│                                                                             │
│  PLACEMENT 5: PUBLISH ATTEMPT ✓                                             │
│  ────────────────────────────────                                           │
│  When: User tries to publish their site                                     │
│  Type: Feature gate - "Upgrade to publish your site live"                   │
│  Why: Ultimate high-intent moment - they want their site online             │
│                                                                             │
│  PLACEMENT 6: DOMAIN PURCHASE ✓                                             │
│  ────────────────────────────────                                           │
│  When: User searches for a domain                                           │
│  Type: Upsell - "Get a free domain with annual plan"                        │
│  Why: Value-add moment - domain is tangible benefit                         │
│                                                                             │
│  PLACEMENT 7: TRANSACTION ABANDONMENT ✓                                     │
│  ────────────────────────────────                                           │
│  When: User closes payment popup without completing                         │
│  Type: Last-chance discount offer                                           │
│  Why: Recover users who had second thoughts                                 │
│                                                                             │
│  PLACEMENT 8: TRIAL ENDING ✓                                                │
│  ────────────────────────────────                                           │
│  When: 2 days before trial ends + day of ending                             │
│  Type: Email + In-app reminder with conversion offer                        │
│  Why: Critical conversion moment                                            │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

## 4.2 Placement Priority

| Placement | Priority | Expected Impact | Implementation |
|-----------|----------|-----------------|----------------|
| Post-Onboarding | P0 | 40% of conversions | Sprint 6 |
| First AI Generation | P0 | 25% of conversions | Sprint 6 |
| Publish Attempt | P0 | 15% of conversions | Sprint 6 |
| Credit Exhaustion | P1 | 10% of conversions | Sprint 7 |
| Transaction Abandonment | P1 | 5% of conversions | Sprint 7 |
| Session Start | P2 | 3% of conversions | Sprint 8 |
| Domain Purchase | P2 | 2% of conversions | Sprint 8 |
| Trial Ending | P0 | Critical | Sprint 6 |

---

# PART 5: TRANSACTION ABANDONMENT RECOVERY

## 5.1 Abandonment Flow

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    TRANSACTION ABANDONMENT RECOVERY                         │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  TRIGGER: User clicks "Subscribe" → Opens payment → Closes without paying  │
│                                                                             │
│  ─────────────────────────────────────────────────────────────────────────  │
│                                                                             │
│  IMMEDIATE (0-3 seconds after close):                                       │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                                                                     │   │
│  │                           انتظر! 🎁                                 │   │
│  │                                                                     │   │
│  │         لاحظنا أنك لم تكمل الاشتراك...                               │   │
│  │         إليك عرض خاص لك فقط:                                        │   │
│  │                                                                     │   │
│  │    ┌─────────────────────────────────────────────────────────┐     │   │
│  │    │                                                         │     │   │
│  │    │     خصم 20% على الباقة السنوية                          │     │   │
│  │    │                                                         │     │   │
│  │    │     23 د.ك  →  18.40 د.ك                                │     │   │
│  │    │     ─────      ──────────                               │     │   │
│  │    │                                                         │     │   │
│  │    │     ⏰ ينتهي العرض خلال: 14:59                          │     │   │
│  │    │                                                         │     │   │
│  │    └─────────────────────────────────────────────────────────┘     │   │
│  │                                                                     │   │
│  │         [استخدم العرض الآن ←]     [لا، شكراً]                       │   │
│  │                                                                     │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  IF DECLINED → Wait 24 hours → Send email with same/better offer           │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

## 5.2 Abandonment Email Sequence

| Email | Timing | Subject (Arabic) | Offer |
|-------|--------|------------------|-------|
| Email 1 | 1 hour | "نسيت شيئاً؟ 🤔" | Same 20% off |
| Email 2 | 24 hours | "عرضك الخاص ينتهي قريباً ⏰" | 25% off |
| Email 3 | 72 hours | "آخر فرصة: أكبر خصم لدينا 🎁" | 30% off |

---

# PART 6: LUCKY SPIN DISCOUNT WHEEL

## 6.1 Spin Wheel Design

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                          LUCKY SPIN WHEEL                                   │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  TRIGGER: Special occasions, first-time visitors, or high-intent moments   │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                                                                     │   │
│  │                      🎰 لفّ واربح!                                  │   │
│  │                                                                     │   │
│  │                    جائزتك في انتظارك                               │   │
│  │                                                                     │   │
│  │              ┌─────────────────────────────┐                        │   │
│  │              │                             │                        │   │
│  │              │      ╭───────────────╮      │                        │   │
│  │              │     ╱   10%  │ 15%   ╲     │                        │   │
│  │              │    ╱─────────┼─────────╲    │                        │   │
│  │              │   │   5%    ▼    20%   │   │                        │   │
│  │              │    ╲─────────┼─────────╱    │                        │   │
│  │              │     ╲   25%  │ 30%   ╱     │                        │   │
│  │              │      ╰───────────────╯      │                        │   │
│  │              │                             │                        │   │
│  │              └─────────────────────────────┘                        │   │
│  │                                                                     │   │
│  │                    [🎯 لفّ الآن]                                    │   │
│  │                                                                     │   │
│  │              أدخل بريدك لتحصل على جائزتك:                           │   │
│  │              ┌─────────────────────────────┐                        │   │
│  │              │ your@email.com              │                        │   │
│  │              └─────────────────────────────┘                        │   │
│  │                                                                     │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  PROBABILITIES (Weighted for profitability):                                │
│  • 5% off  → 5% chance                                                     │
│  • 10% off → 30% chance                                                    │
│  • 15% off → 35% chance  ← Most common                                     │
│  • 20% off → 20% chance                                                    │
│  • 25% off → 8% chance                                                     │
│  • 30% off → 2% chance                                                     │
│                                                                             │
│  WHY IT WORKS:                                                              │
│  • Gamification triggers dopamine                                          │
│  • "Winning" creates commitment to use the discount                        │
│  • Email capture for remarketing                                           │
│  • Higher conversion than static discount                                  │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

## 6.2 Spin Wheel Implementation

```typescript
interface SpinWheelConfig {
  prizes: SpinPrize[];
  triggerConditions: TriggerCondition[];
  expiryHours: number;
  maxSpinsPerUser: number;
}

interface SpinPrize {
  id: string;
  discountPercent: number;
  probability: number;      // Must sum to 100
  labelAr: string;
  labelEn: string;
  color: string;
}

const spinWheelPrizes: SpinPrize[] = [
  { id: 'p5', discountPercent: 5, probability: 5, labelAr: 'خصم 5%', color: '#F3F4F6' },
  { id: 'p10', discountPercent: 10, probability: 30, labelAr: 'خصم 10%', color: '#DBEAFE' },
  { id: 'p15', discountPercent: 15, probability: 35, labelAr: 'خصم 15%', color: '#FEF3C7' },
  { id: 'p20', discountPercent: 20, probability: 20, labelAr: 'خصم 20%', color: '#D1FAE5' },
  { id: 'p25', discountPercent: 25, probability: 8, labelAr: 'خصم 25%', color: '#FCE7F3' },
  { id: 'p30', discountPercent: 30, probability: 2, labelAr: 'خصم 30%', color: '#FEE2E2' },
];

type TriggerCondition = 
  | 'first_visit'
  | 'exit_intent'
  | 'special_event'
  | 'ramadan'
  | 'eid'
  | 'national_day';
```

---

# PART 7: PRICING PSYCHOLOGY

## 7.1 Price Display Rules

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                       PRICE DISPLAY PSYCHOLOGY                              │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  RULE 1: Lead with FREE                                                     │
│  ────────────────────────                                                   │
│  ❌ WRONG: "الباقة السنوية - 23 د.ك"                                        │
│  ✅ RIGHT: "جرّب مجاناً" ... (price revealed after click)                   │
│                                                                             │
│  RULE 2: Weekly breakdown                                                   │
│  ────────────────────────                                                   │
│  ❌ WRONG: "23 د.ك/سنة"                                                     │
│  ✅ RIGHT: "فقط 0.44 د.ك أسبوعياً (23 د.ك/سنة)"                             │
│                                                                             │
│  RULE 3: Anchor with comparison                                             │
│  ────────────────────────                                                   │
│  ❌ WRONG: Just show 23 KWD                                                 │
│  ✅ RIGHT: "52 د.ك ← 23 د.ك (وفّر 40%)"                                     │
│                                                                             │
│  RULE 4: Psychological pricing                                              │
│  ────────────────────────                                                   │
│  ❌ WRONG: 23 د.ك, 38 د.ك, 59 د.ك                                           │
│  ✅ RIGHT: 22.99 د.ك, 37.50 د.ك, 58.75 د.ك                                  │
│                                                                             │
│  RULE 5: Value framing                                                      │
│  ────────────────────────                                                   │
│  ❌ WRONG: "23 د.ك للاشتراك"                                                │
│  ✅ RIGHT: "23 د.ك = موقع احترافي + نطاق مجاني + دعم 24/7"                  │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

## 7.2 Updated Pricing Display

| Tier | Original | Display Price | Weekly | Savings |
|------|----------|--------------|--------|---------|
| Basic | 23 KWD | 22.99 د.ك | 0.44 د.ك/أسبوع | - |
| Pro | 38 KWD | 37.50 د.ك | 0.72 د.ك/أسبوع | - |
| Premium | 59 KWD | 58.75 د.ك | 1.13 د.ك/أسبوع | - |
| Enterprise | 75 KWD | 74.50 د.ك | 1.43 د.ك/أسبوع | - |

## 7.3 Price Card Design

```
┌─────────────────────────────────────────────────────────────────┐
│                       ⭐ الأكثر شعبية                           │
│  ───────────────────────────────────────────────────────────── │
│                                                                 │
│                         الباقة الأساسية                        │
│                                                                 │
│                    ┌─────────────────────┐                     │
│                    │      مجاناً         │                     │
│                    │                     │                     │
│                    │   لمدة أسبوع       │                     │
│                    └─────────────────────┘                     │
│                                                                 │
│                    ثم 22.99 د.ك/سنة                            │
│                    (فقط 0.44 د.ك/أسبوع)                        │
│                                                                 │
│  ───────────────────────────────────────────────────────────── │
│                                                                 │
│   ✓ مواقع غير محدودة                                          │
│   ✓ 100 نقطة AI يومياً                                        │
│   ✓ قوالب عربية جاهزة                                         │
│   ✓ نطاق مجاني (للنطاقات أقل من $15)                           │
│   ✓ شهادة SSL مجانية                                          │
│   ✓ دعم عبر الواتساب                                          │
│                                                                 │
│           ┌─────────────────────────────────┐                  │
│           │    ابدأ تجربتك المجانية ←      │                  │
│           └─────────────────────────────────┘                  │
│                                                                 │
│              لن يُخصم أي مبلغ اليوم                            │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

# PART 8: CONVERSION FUNNEL TRACKING

## 8.1 Funnel Stages

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         CONVERSION FUNNEL                                   │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  Install/Visit  →  Signup  →  Trial Start  →  Active Trial  →  Paid        │
│      100%           60%          40%            25%            12%          │
│       ▼              ▼            ▼              ▼              ▼           │
│                                                                             │
│  [    Drop-off Analysis    ]                                                │
│                                                                             │
│  • Visit → Signup: 40% drop                                                │
│    → Fix: Better landing page, clearer value prop                          │
│                                                                             │
│  • Signup → Trial: 20% drop                                                │
│    → Fix: Simpler onboarding, immediate value                              │
│                                                                             │
│  • Trial → Active: 15% drop                                                │
│    → Fix: Better engagement emails, in-app guidance                        │
│                                                                             │
│  • Active → Paid: 13% drop                                                 │
│    → Fix: Better paywall design, offers, reminders                         │
│                                                                             │
│  TARGET: Improve each stage by 5% = double conversions                     │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

## 8.2 Tracking Metrics

```typescript
interface PaywallMetrics {
  // Impression metrics
  paywallImpressions: number;
  paywallDismissals: number;
  
  // Step metrics (multi-step)
  step1Views: number;
  step1Continues: number;
  step2Views: number;
  step2Continues: number;
  step3Views: number;
  step3CTAClicks: number;
  
  // Conversion metrics
  paymentStarted: number;
  paymentCompleted: number;
  paymentAbandoned: number;
  
  // Trial metrics
  trialStarted: number;
  trialActiveDay7: number;
  trialConverted: number;
  trialChurned: number;
  
  // Offer metrics
  discountOffered: number;
  discountUsed: number;
  spinWheelPlayed: number;
  spinWheelConverted: number;
  
  // Calculated
  paywallConversionRate: number;     // paymentCompleted / paywallImpressions
  trialConversionRate: number;        // trialConverted / trialStarted
  abandonmentRecoveryRate: number;    // recovered / abandoned
}
```

## 8.3 Dashboard Widget

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    📊 لوحة تحويل الباي وول                                 │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│   اليوم                   هذا الأسبوع              هذا الشهر              │
│  ┌──────────────┐        ┌──────────────┐        ┌──────────────┐          │
│  │    12.4%     │        │    11.8%     │        │    10.5%     │          │
│  │   ▲ +1.2%    │        │   ▲ +0.8%    │        │   ▼ -0.3%    │          │
│  │  معدل التحويل │        │  معدل التحويل │        │  معدل التحويل │          │
│  └──────────────┘        └──────────────┘        └──────────────┘          │
│                                                                             │
│  ───────────────────────────────────────────────────────────────────────── │
│                                                                             │
│  📈 أداء المراحل:                                                          │
│                                                                             │
│  الخطوة 1 (الفوائد)    ████████████████████░░░░░  82% متابعة              │
│  الخطوة 2 (الثقة)      ██████████████████░░░░░░░  75% متابعة              │
│  الخطوة 3 (العروض)     ████████████░░░░░░░░░░░░░  55% نقر CTA             │
│  الدفع                  ███████░░░░░░░░░░░░░░░░░░  35% إكمال               │
│                                                                             │
│  ───────────────────────────────────────────────────────────────────────── │
│                                                                             │
│  💡 توصيات:                                                                │
│  • الخطوة 3 لديها أكبر انخفاض - جرّب تصميم جديد للعروض                    │
│  • نسبة إكمال الدفع منخفضة - فعّل استرداد التخلي                           │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

# PART 9: DATABASE SCHEMA

## 9.1 Paywall Tables

```sql
-- Paywall impressions and interactions
CREATE TABLE paywall_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id),
  session_id VARCHAR(100),
  
  -- Event details
  event_type VARCHAR(50) NOT NULL,
  -- Types: impression, step1_view, step1_continue, step2_view, step2_continue,
  --        step3_view, cta_click, payment_started, payment_completed, 
  --        payment_abandoned, trial_started, trial_converted, 
  --        discount_offered, discount_used, spin_played, spin_won
  
  paywall_type VARCHAR(50),        -- post_onboarding, credit_exhaustion, etc.
  paywall_version VARCHAR(20),     -- For A/B testing
  step_number INTEGER,
  
  -- Offer details
  offer_type VARCHAR(50),          -- trial, no_trial, discount, spin
  discount_percent INTEGER,
  plan_selected VARCHAR(50),       -- basic, pro, premium, enterprise
  
  -- Metadata
  metadata JSONB DEFAULT '{}',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Trial tracking
CREATE TABLE trial_tracking (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) UNIQUE,
  subscription_id UUID REFERENCES subscriptions(id),
  
  trial_started_at TIMESTAMP WITH TIME ZONE NOT NULL,
  trial_ends_at TIMESTAMP WITH TIME ZONE NOT NULL,
  
  -- Engagement tracking
  days_active INTEGER DEFAULT 0,
  projects_created INTEGER DEFAULT 0,
  credits_used INTEGER DEFAULT 0,
  
  -- Reminders
  day5_reminder_sent BOOLEAN DEFAULT false,
  day6_reminder_sent BOOLEAN DEFAULT false,
  day7_reminder_sent BOOLEAN DEFAULT false,
  
  -- Outcome
  status VARCHAR(20) DEFAULT 'active',
  -- Status: active, converted, churned, extended
  converted_at TIMESTAMP WITH TIME ZONE,
  conversion_offer VARCHAR(50),
  
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Discount codes and usage
CREATE TABLE discount_codes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  code VARCHAR(50) UNIQUE NOT NULL,
  discount_percent INTEGER NOT NULL,
  discount_type VARCHAR(20) DEFAULT 'percent',
  
  -- Validity
  valid_from TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  valid_until TIMESTAMP WITH TIME ZONE,
  max_uses INTEGER,
  current_uses INTEGER DEFAULT 0,
  
  -- Targeting
  target_plans TEXT[] DEFAULT '{}',      -- Empty = all plans
  target_users TEXT[] DEFAULT '{}',      -- Empty = all users
  source VARCHAR(50),                    -- spin_wheel, abandonment, referral, etc.
  
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE discount_usage (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  discount_code_id UUID NOT NULL REFERENCES discount_codes(id),
  user_id UUID NOT NULL REFERENCES users(id),
  subscription_id UUID REFERENCES subscriptions(id),
  
  original_price NUMERIC(10,3) NOT NULL,
  discounted_price NUMERIC(10,3) NOT NULL,
  savings NUMERIC(10,3) NOT NULL,
  
  used_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Spin wheel entries
CREATE TABLE spin_wheel_entries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id),
  email VARCHAR(255),
  
  prize_won INTEGER NOT NULL,            -- Discount percent
  discount_code_id UUID REFERENCES discount_codes(id),
  
  redeemed BOOLEAN DEFAULT false,
  redeemed_at TIMESTAMP WITH TIME ZONE,
  
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indexes
CREATE INDEX idx_paywall_events_user ON paywall_events(user_id);
CREATE INDEX idx_paywall_events_type ON paywall_events(event_type);
CREATE INDEX idx_paywall_events_created ON paywall_events(created_at);
CREATE INDEX idx_trial_tracking_user ON trial_tracking(user_id);
CREATE INDEX idx_trial_tracking_ends ON trial_tracking(trial_ends_at);
CREATE INDEX idx_discount_codes_code ON discount_codes(code);

-- RLS
ALTER TABLE paywall_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE trial_tracking ENABLE ROW LEVEL SECURITY;
ALTER TABLE discount_codes ENABLE ROW LEVEL SECURITY;
ALTER TABLE discount_usage ENABLE ROW LEVEL SECURITY;
ALTER TABLE spin_wheel_entries ENABLE ROW LEVEL SECURITY;
```

---

# PART 10: A/B TESTING FRAMEWORK

## 10.1 Test Categories

| Category | Tests to Run |
|----------|--------------|
| **Step Count** | 2-step vs. 3-step vs. 4-step paywall |
| **CTA Copy** | "ابدأ مجاناً" vs. "جرّب الآن" vs. "انضم إلينا" |
| **Price Display** | Full price first vs. Weekly breakdown first |
| **Social Proof** | With testimonials vs. Without vs. Star ratings only |
| **Urgency** | With timer vs. Without timer |
| **Trial Toggle** | With toggle vs. Trial only vs. No trial |
| **Discount** | No discount vs. 10% vs. 20% vs. Spin wheel |

## 10.2 Test Implementation

```typescript
interface ABTest {
  id: string;
  name: string;
  description: string;
  
  variants: ABVariant[];
  trafficSplit: number[];            // e.g., [50, 50] or [33, 33, 34]
  
  startDate: Date;
  endDate?: Date;
  
  primaryMetric: string;             // e.g., 'paywall_conversion_rate'
  secondaryMetrics: string[];
  
  status: 'draft' | 'running' | 'paused' | 'completed';
  winningVariant?: string;
}

interface ABVariant {
  id: string;
  name: string;
  config: Record<string, any>;       // Variant-specific configuration
  
  // Results
  impressions: number;
  conversions: number;
  conversionRate: number;
  statisticalSignificance: number;
}

// Example test configuration
const ctaCopyTest: ABTest = {
  id: 'cta-copy-test-001',
  name: 'CTA Copy Test - December 2025',
  description: 'Testing different CTA text on step 3',
  
  variants: [
    { id: 'control', name: 'ابدأ مجاناً', config: { ctaText: 'ابدأ مجاناً' } },
    { id: 'variant_a', name: 'جرّب الآن', config: { ctaText: 'جرّب الآن' } },
    { id: 'variant_b', name: 'ابدأ رحلتك', config: { ctaText: 'ابدأ رحلتك' } },
  ],
  trafficSplit: [34, 33, 33],
  
  startDate: new Date('2025-12-28'),
  primaryMetric: 'step3_cta_click_rate',
  secondaryMetrics: ['payment_completed', 'trial_started'],
  
  status: 'running'
};
```

---

# PART 11: IMPLEMENTATION TIMELINE

## 11.1 Sprint Schedule

| Sprint | Focus | Deliverables |
|--------|-------|--------------|
| **Sprint 6** | Core Paywall | 3-step flow, placement 1-3, trial system |
| **Sprint 7** | Advanced Features | Transaction recovery, trial toggle, placements 4-5 |
| **Sprint 8** | Optimization | Spin wheel, placements 6-7, A/B testing |
| **Sprint 9** | Analytics | Full dashboard, funnel tracking, reporting |

## 11.2 Key Milestones

| Milestone | Date | Success Criteria |
|-----------|------|------------------|
| Paywall v1 Live | Week 6 | Basic 3-step flow working |
| Trial System Live | Week 6 | Users can start/manage trials |
| Conversion Rate 10%+ | Week 8 | Initial paywall optimization |
| Conversion Rate 15%+ | Week 10 | Advanced optimizations |
| Conversion Rate 20%+ | Month 3 | Full optimization cycle |

---

# APPENDIX A: QUICK REFERENCE

## Arabic Paywall Copy Cheatsheet

| Element | Copy (Arabic) |
|---------|---------------|
| Main CTA | ابدأ تجربتك المجانية ← |
| Secondary CTA | جرّب الآن مجاناً |
| Price anchor | ~~52 د.ك~~ 22.99 د.ك |
| Weekly breakdown | فقط 0.44 د.ك/أسبوع |
| Savings | وفّر 40% |
| Trust badge | 🔒 دفع آمن |
| No payment | لن يُخصم أي مبلغ اليوم |
| Cancel anytime | يمكنك الإلغاء في أي وقت |
| Limited offer | عرض محدود |
| Timer | ينتهي العرض خلال: |

---

**Document Version:** 1.0  
**Created:** December 2025  
**Owner:** Growth + Product Team  
**Sprint:** 6-9
